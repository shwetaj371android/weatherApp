package com.shweta.weatherapplication.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shweta.weatherapplication.api.NetworkResult
import com.shweta.weatherapplication.api.repository.WeatherRepository
import com.shweta.weatherapplication.model.WeatherResponse
import com.shweta.weatherapplication.utils.AppConstant
import com.shweta.weatherapplication.utils.getCurrentDateTime
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class DashboardViewModel @Inject constructor(private val weatherRepository: WeatherRepository) :
    ViewModel() {
    val weatherCondition = MutableLiveData<WeatherResponse>()
    val currentDate = MutableLiveData<String>()
    val isWithData = MutableLiveData<Boolean>()
    val isWithNoData = MutableLiveData<Boolean>()
    val isShowLoading = MutableLiveData<Boolean>()

    val weatherResponseLiveData: LiveData<NetworkResult<WeatherResponse>>
        get() = weatherRepository.weatherResponseLiveData

    /**
     * Call API and get weather data
     * @param latitude
     * @param longitude
     */
    fun getWeatherData(
        latitude: String,
        longitude: String
    ) = viewModelScope.launch {
        weatherRepository.getCurrentWeatherData(latitude = latitude, longitude = longitude)
    }

    /**
     * Set data to livedata Variables
     * @param apiResponse WeatherResponse response object
     */
    fun setData(apiResponse: WeatherResponse) {
        weatherCondition.value = apiResponse
        currentDate.value = getCurrentDateTime(AppConstant.DATE_FORMAT)
    }
}