package com.shweta.weatherapplication.model

import java.io.Serializable

data class WeatherResponse(
    val base: String,
    val clouds: CloudsModel,
    val cod: Int,
    val coord: Coords,
    val dt: Int,
    val id: Int,
    val main: Main,
    val name: String,
    val sys: SysCountry,
    val timezone: Int,
    val visibility: Int,
    val weather: List<WeatherModel>,
    val wind: Wind
) : Serializable