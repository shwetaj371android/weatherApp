package com.shweta.weatherapplication.model

import java.io.Serializable

data class Coords(
    val lat: Double,
    val lon: Double
) : Serializable