package com.shweta.weatherapplication.api.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.shweta.weatherapplication.api.ApiService
import com.shweta.weatherapplication.api.NetworkResult
import com.shweta.weatherapplication.model.WeatherResponse
import com.shweta.weatherapplication.model.ErrorModel
import com.shweta.weatherapplication.utils.AppConstant
import retrofit2.Response
import java.net.SocketTimeoutException
import javax.inject.Inject

class WeatherByCityRepository @Inject constructor(private val storeApiServices: ApiService) {

    private val weatherResponseDataMutableLiveData =
        MutableLiveData<NetworkResult<WeatherResponse>>()

    val weatherResponseLiveData: LiveData<NetworkResult<WeatherResponse>>
        get() = weatherResponseDataMutableLiveData

    suspend fun getCurrentWeatherForCityData(cityName: String) {
        try {
            weatherResponseDataMutableLiveData.postValue(NetworkResult.Loading())
            val response = storeApiServices.getCurrentWeatherDataForCity(
                cityName = cityName,
                unit = AppConstant.UNIT_METRIC
            )
            handleResponse(response)
        } catch (exception: Exception) {
            if (exception is SocketTimeoutException) {
                weatherResponseDataMutableLiveData.postValue(
                    NetworkResult.Error(
                        ErrorModel(
                            "SocketTimeoutException",
                            10
                        )
                    )
                )
            } else {
                weatherResponseDataMutableLiveData.postValue(
                    NetworkResult.Error(
                        ErrorModel(
                            "Network Exception",
                            10
                        )
                    )
                )
            }
        }
    }

    private fun handleResponse(response: Response<WeatherResponse>) {
        if (response.isSuccessful && response.body() != null) {
            weatherResponseDataMutableLiveData.postValue(NetworkResult.Success(response.body()))
        } else if (response.errorBody() != null) {
            val errorModel = Gson().fromJson(response.errorBody()?.string(), ErrorModel::class.java)
            weatherResponseDataMutableLiveData.postValue(NetworkResult.Error(errorModel))
        } else {
            weatherResponseDataMutableLiveData.postValue(
                NetworkResult.Error(
                    ErrorModel(
                        "Exception",
                        10
                    )
                )
            )
        }
    }
}