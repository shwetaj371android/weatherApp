package com.shweta.weatherapplication.model

import java.io.Serializable

data class SysCountry(
    val country: String,
    val sunrise: Int,
    val sunset: Int
) : Serializable