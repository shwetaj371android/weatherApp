package com.shweta.weatherapplication

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MyWeatherReport : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}