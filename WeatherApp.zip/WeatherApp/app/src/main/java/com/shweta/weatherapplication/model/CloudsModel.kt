package com.shweta.weatherapplication.model

import java.io.Serializable

data class CloudsModel(
    val all: Int
): Serializable