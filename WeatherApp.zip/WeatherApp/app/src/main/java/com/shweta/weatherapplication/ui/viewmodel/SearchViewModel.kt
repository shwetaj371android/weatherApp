package com.shweta.weatherapplication.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shweta.weatherapplication.api.NetworkResult
import com.shweta.weatherapplication.api.repository.WeatherByCityRepository
import com.shweta.weatherapplication.model.WeatherResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class SearchViewModel @Inject constructor(private val weatherRepository: WeatherByCityRepository) :
    ViewModel() {
    lateinit var apiResponse: WeatherResponse
    val cityName = MutableLiveData<String>()
    val countryName = MutableLiveData<String>()

    val weatherResponseLiveData: LiveData<NetworkResult<WeatherResponse>>
        get() = weatherRepository.weatherResponseLiveData

    fun getWeatherDataForCity(
        cityName: String
    ) = viewModelScope.launch {
        weatherRepository.getCurrentWeatherForCityData(cityName = cityName)
    }

    fun setData(apiResponse: WeatherResponse) {
        this.apiResponse = apiResponse
        if (apiResponse.sys.country.isNotBlank()) {
            countryName.value = apiResponse.sys.country.toString()
        }
        if (apiResponse.name.isNotBlank()) {
            cityName.value = apiResponse.name
        }
    }

    fun getApiResponseObject(): WeatherResponse? {
        return if (this::apiResponse.isInitialized) {
            apiResponse
        } else null
    }
}