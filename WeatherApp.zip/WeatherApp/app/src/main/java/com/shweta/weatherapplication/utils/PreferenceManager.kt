package com.shweta.weatherapplication.utils

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.shweta.weatherapplication.model.WeatherResponse
import com.shweta.weatherapplication.utils.AppConstant.PREFERENCE_FILE
import com.shweta.weatherapplication.utils.AppConstant.SAVED_CITY_DATA_KEY
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class PreferenceManager @Inject constructor(@ApplicationContext context: Context) {
    private var preferences: SharedPreferences =
        context.getSharedPreferences(PREFERENCE_FILE, Context.MODE_PRIVATE)

    fun saveCityWeatherObject(weatherObject: WeatherResponse?) {
        val editor = preferences.edit()
        editor.putString(SAVED_CITY_DATA_KEY, Gson().toJson(weatherObject))
        editor.apply()
    }

    fun getSelectedStoreObject(): WeatherResponse? {
        val stringObject = preferences.getString(SAVED_CITY_DATA_KEY, null)
        return Gson().fromJson(stringObject, WeatherResponse::class.java)
    }

    fun clearAllData() {
        val editor = preferences.edit()
        editor.clear().apply()
    }
}